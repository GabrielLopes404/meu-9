import { Palette, Code2, TrendingUp, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

const pillars = [
  {
    id: "design",
    icon: Palette,
    title: "Design Gráfico",
    description: "Identidade visual, social media, 3D e motion design para marcas que querem se destacar.",
    features: ["Identidade Visual", "Social Media", "Design 3D", "Motion Graphics"],
    color: "from-primary to-pink-600",
    glow: "rgba(236,72,153,0.4)",
    link: "#servicos"
  },
  {
    id: "web",
    icon: Code2,
    title: "Sites & Sistemas",
    description: "Desenvolvimento web completo, do design ao código, com tecnologias modernas e performance máxima.",
    features: ["Landing Pages", "E-commerce", "Sistemas Web", "Apps Personalizados"],
    color: "from-blue-600 to-cyan-500",
    glow: "rgba(59,130,246,0.4)",
    link: "#web-development"
  },
  {
    id: "traffic",
    icon: TrendingUp,
    title: "Gestão de Tráfego",
    description: "Estratégias de marketing digital, anúncios pagos e otimização para maximizar seus resultados.",
    features: ["Google Ads", "Meta Ads", "Analytics", "Otimização de ROI"],
    color: "from-green-600 to-emerald-500",
    glow: "rgba(34,197,94,0.4)",
    link: "#traffic"
  }
];

export function ServicesOverview() {
  const scrollToSection = (sectionId: string) => {
    const element = document.querySelector(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section className="py-24 md:py-32 bg-gradient-to-b from-[#050505] via-[#0a0a0a] to-[#050505] relative overflow-hidden">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
      <motion.div
        animate={{
          opacity: [0.03, 0.08, 0.03],
          scale: [1, 1.1, 1]
        }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent"
      />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16 md:mb-20 space-y-4"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-primary/20 to-primary/10 border border-primary/40 mb-4 shadow-[0_0_30px_rgba(236,72,153,0.3)]"
          >
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse"></div>
            <span className="text-sm font-medium text-primary uppercase tracking-wider">Nossas Especialidades</span>
          </motion.div>
          
          <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl uppercase tracking-tight text-white">
            Soluções Completas Para
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-blue-500 to-green-500">Transformar Seu Negócio</span>
          </h2>
          
          <p className="text-base md:text-lg text-white/60 max-w-3xl mx-auto leading-relaxed">
            Da criação da identidade visual ao desenvolvimento web e captação de clientes — 
            <span className="text-white font-semibold"> tudo em um só lugar</span>, com qualidade profissional e resultados comprovados.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            {pillars.map((pillar, index) => {
            const Icon = pillar.icon;
            return (
              <motion.div
                key={pillar.id}
                initial={{ opacity: 0, y: 50, scale: 0.9 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{
                  duration: 0.6,
                  delay: index * 0.15,
                  ease: [0.22, 1, 0.36, 1]
                }}
                whileHover={{ y: -16, scale: 1.03 }}
                className="group relative rounded-3xl bg-gradient-to-br from-[#1f1f1f] via-[#141414] to-[#0a0a0a] border border-white/10 hover:border-white/40 transition-all duration-500 p-8 shadow-[0_0_0_rgba(0,0,0,0)] hover:shadow-[0_0_80px_var(--pillar-glow)] backdrop-blur-sm"
                style={{ "--pillar-glow": pillar.glow } as React.CSSProperties}
              >
                <motion.div
                  className="absolute top-0 right-0 w-40 h-40 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" 
                  style={{ background: pillar.glow }}
                />
                
                <div className="relative z-10 space-y-6 h-full flex flex-col">
                  <div className="flex items-start justify-between">
                    <motion.div
                      whileHover={{ scale: 1.2, rotate: 15 }}
                      transition={{ type: "spring", stiffness: 400, damping: 12 }}
                      className={`w-18 h-18 rounded-2xl bg-gradient-to-br ${pillar.color} flex items-center justify-center shadow-2xl`}
                      style={{ boxShadow: `0 15px 50px ${pillar.glow}` }}
                    >
                      <Icon className="w-9 h-9 text-white drop-shadow-lg" />
                    </motion.div>
                    <div className="text-xs font-bold text-white/40 uppercase tracking-wider">
                      0{index + 1}
                    </div>
                  </div>
                  
                  <div className="space-y-3 flex-grow">
                    <h3 className="font-display font-bold text-2xl md:text-3xl text-white group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-white/80 transition-all duration-300">
                      {pillar.title}
                    </h3>
                    
                    <p className="text-base text-white/70 leading-relaxed">
                      {pillar.description}
                    </p>
                  </div>

                  <div className="space-y-3 pt-4 border-t border-white/10">
                    <div className="text-xs text-white/50 font-semibold uppercase tracking-wider mb-2">
                      Principais Serviços
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {pillar.features.map((feature, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, x: -10 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          viewport={{ once: true }}
                          transition={{ delay: index * 0.15 + i * 0.05 }}
                          className="flex items-center gap-2 text-sm text-white/80"
                        >
                          <div className={`w-1.5 h-1.5 rounded-full bg-gradient-to-r ${pillar.color}`}></div>
                          <span>{feature}</span>
                        </motion.div>
                      ))}
                    </div>
                  </div>

                  <motion.button
                    onClick={() => scrollToSection(pillar.link)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`mt-6 w-full flex items-center justify-center gap-2 px-6 py-4 rounded-xl bg-gradient-to-r ${pillar.color} text-white font-bold text-sm uppercase tracking-wide transition-all`}
                    style={{ boxShadow: `0 10px 30px ${pillar.glow}` }}
                  >
                    SAIBA MAIS
                    <motion.div whileHover={{ x: 5 }}>
                      <ArrowRight className="w-4 h-4" />
                    </motion.div>
                  </motion.button>
                </div>
              </motion.div>
            );
            })}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6 }}
          className="text-center mt-16"
        >
          <p className="text-white/50 text-sm mb-6">Mais de <span className="text-primary font-bold">350 projetos</span> entregues com excelência</p>
          <div className="flex flex-wrap items-center justify-center gap-8 opacity-50">
            <div className="text-xs text-white/40 font-mono">100% de Satisfação</div>
            <div className="w-1 h-1 rounded-full bg-white/30"></div>
            <div className="text-xs text-white/40 font-mono">5+ Anos de Experiência</div>
            <div className="w-1 h-1 rounded-full bg-white/30"></div>
            <div className="text-xs text-white/40 font-mono">Suporte Completo</div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
