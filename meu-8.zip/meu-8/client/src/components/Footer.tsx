import { SiInstagram } from "react-icons/si";
import { Award } from "lucide-react";

export function Footer() {
  const currentYear = new Date().getFullYear();

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <footer className="bg-background border-t border-border" data-testid="footer-main">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div className="space-y-4">
            <div className="flex items-center gap-2" data-testid="logo-footer">
              <img 
                src="/attached_assets/image_1763748592137.png" 
                alt="Lopes Designer" 
                className="h-10 w-auto"
              />
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed" data-testid="text-footer-description">
              Design gráfico profissional que transforma marcas em experiências memoráveis.
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="font-display font-bold text-lg uppercase tracking-wide" data-testid="text-footer-quicklinks-title">
              Links Rápidos
            </h3>
            <nav className="flex flex-col gap-2">
              <button
                onClick={() => scrollToSection("servicos")}
                className="text-sm text-muted-foreground hover:text-primary transition-colors text-left"
                data-testid="footer-link-services"
              >
                Serviços
              </button>
              <button
                onClick={() => scrollToSection("portfolio")}
                className="text-sm text-muted-foreground hover:text-primary transition-colors text-left"
                data-testid="footer-link-portfolio"
              >
                Portfolio
              </button>
              <button
                onClick={() => scrollToSection("faq")}
                className="text-sm text-muted-foreground hover:text-primary transition-colors text-left"
                data-testid="footer-link-faq"
              >
                FAQ
              </button>
            </nav>
          </div>

          <div className="space-y-4">
            <h3 className="font-display font-bold text-lg uppercase tracking-wide" data-testid="text-footer-contact-title">
              Contato
            </h3>
            <div className="space-y-3">
              <a
                href="https://www.instagram.com/lopesdesigner_ofc/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors group"
                data-testid="footer-link-instagram"
              >
                <SiInstagram className="w-4 h-4 group-hover:scale-110 transition-transform" />
                @lopesdesigner_ofc
              </a>
              <p className="text-sm text-muted-foreground" data-testid="text-footer-response-time">
                Resposta em até 24h
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-display font-bold text-lg uppercase tracking-wide" data-testid="text-footer-credibility-title">
              Credibilidade
            </h3>
            <div className="flex items-center gap-3 p-4 rounded-lg bg-primary/5 border border-primary/20" data-testid="card-footer-credibility">
              <Award className="w-8 h-8 text-primary flex-shrink-0" />
              <div>
                <div className="font-display font-bold text-2xl text-primary" data-testid="text-footer-projects-count">350+</div>
                <div className="text-xs text-muted-foreground uppercase tracking-wide" data-testid="text-footer-projects-label">
                  Projetos Entregues
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground" data-testid="text-footer-copyright">
              © {currentYear} Lopes Designer. Todos os direitos reservados.
            </p>
            <p className="text-sm text-muted-foreground" data-testid="text-footer-credits">
              Site feito por <span className="text-primary font-semibold">Lopes</span>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
