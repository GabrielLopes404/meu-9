import { ChevronRight } from "lucide-react";
import { useEffect, useState, useRef } from "react";

interface ScrollIndicatorProps {
  containerRef?: React.RefObject<HTMLDivElement>;
  children: React.ReactNode;
  className?: string;
}

export function ScrollIndicator({ containerRef, children, className = "" }: ScrollIndicatorProps) {
  const [showLeftGradient, setShowLeftGradient] = useState(false);
  const [showRightGradient, setShowRightGradient] = useState(true);
  const localRef = useRef<HTMLDivElement>(null);
  const ref = containerRef || localRef;

  useEffect(() => {
    const container = ref.current;
    if (!container) return;

    const handleScroll = () => {
      const { scrollLeft, scrollWidth, clientWidth } = container;
      setShowLeftGradient(scrollLeft > 10);
      setShowRightGradient(scrollLeft < scrollWidth - clientWidth - 10);
    };

    handleScroll();
    container.addEventListener("scroll", handleScroll);
    window.addEventListener("resize", handleScroll);

    return () => {
      container.removeEventListener("scroll", handleScroll);
      window.removeEventListener("resize", handleScroll);
    };
  }, [ref]);

  return (
    <div className={`relative ${className}`}>
      {showLeftGradient && (
        <div className="md:hidden absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-[#050505] via-[#050505]/80 to-transparent z-10 pointer-events-none flex items-center justify-start pl-2">
          <div className="w-8 h-8 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center animate-pulse">
            <ChevronRight className="w-5 h-5 text-primary rotate-180" />
          </div>
        </div>
      )}
      
      {showRightGradient && (
        <div className="md:hidden absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-[#050505] via-[#050505]/80 to-transparent z-10 pointer-events-none flex items-center justify-end pr-2">
          <div className="w-8 h-8 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center animate-pulse">
            <ChevronRight className="w-5 h-5 text-primary" />
          </div>
        </div>
      )}
      
      <div ref={ref} className="overflow-x-auto scrollbar-hide scroll-smooth-touch">
        {children}
      </div>
    </div>
  );
}
